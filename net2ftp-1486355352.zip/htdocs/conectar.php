<?
$cone=mysql_connect("sql211.260mb.net","n260m_17214208","v3h0mp5x") or die ("error en la conexion");
$base=mysql_select_db("n260m_17214208_upn_prueba",$cone) or die ("error en la base");
//$base1=mysql_select_db("pruebas",$cone) or die ("error en la base");
?>
