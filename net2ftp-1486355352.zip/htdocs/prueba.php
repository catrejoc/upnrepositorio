<?

echo $_POST['fecha'];
?>