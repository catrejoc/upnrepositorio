<?php
/* http://programarenphp.wordpress.com */
/* incluimos primeramente el archivo que contiene la clase fpdf */
include ('fpdf.php');
/* tenemos que generar una instancia de la clase */
        $pdf = new FPDF();
        $pdf->AddPage();

/* seleccionamos el tipo, estilo y tama�o de la letra a utilizar */
        $pdf->SetFont('Arial', 'B', 14);
		$pdf->Write (7,"PRIMER PDF:  ");
		$pdf->Ln();
		$pdf->Write (7,$_POST['nombre']);
        $pdf->Output("prueba.pdf",'F');
		echo "<script language='javascript'>window.open('prueba.pdf','_self','');</script>";//para ver el archivo pdf generado
		exit;
	?>
