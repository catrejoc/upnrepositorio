		<meta charset = "UTF-8" />
        <div id="ingre">
        <form action="check.php" target="_self" method="post" >
<?
            echo "email<br><input type=email name=nombrex required /><br>";
            echo "contraseña<br><input type=password name=passx required /><br>";

?>
            <br><br>
			<input type="submit" value="Ingresar!!" name="login"/>
		</form>        
       Registrate dando clik <br>
            <a href="registrate.php">Aqui!!!</a>
        </div>
	